package it.unisa.hpc.spark;


import org.apache.spark.SparkConf;
import org.apache.spark.api.java.*;
import org.apache.spark.api.java.function.*;
import scala.Tuple2;


public class SparkDriver {
    public static void main(String[] args) {

        String inputFile = args[0];
        String outputPath = args[1];

        SparkConf conf = new SparkConf().setAppName("Spark Project");
        // Add / to run it locally
        //*
        System.setProperty("hadoop.home.dir", "cartella di hadoop DA INSERIRE");
        System.load("dll di hadoop DA INSERIRE");
        conf.setMaster("local[1]").set("spark.executor.memory", "1g");
        //*/
        JavaSparkContext sc = new JavaSparkContext(conf);
        JavaRDD<String> lines = sc.textFile(inputFile);
        lines = lines.filter((Function<String, Boolean>) s -> {
            String pm10_value = s.split(",")[2];
            return Double.parseDouble(pm10_value)>50;
        });
        JavaPairRDD<String,Integer> sensor_occurrencies = lines.mapToPair((PairFunction<String, String, Integer>) s -> new Tuple2<>(s.split(",")[0],1));
        JavaPairRDD<String, Integer> reduce = sensor_occurrencies.reduceByKey((Function2<Integer, Integer, Integer>) Integer::sum);
        JavaPairRDD<Integer,String> reversed_reduce = reduce.mapToPair((PairFunction<Tuple2<String, Integer>, Integer, String>) stringIntegerTuple2 -> new Tuple2<>(stringIntegerTuple2._2(),stringIntegerTuple2._1() )).sortByKey(false);
        reversed_reduce.saveAsTextFile(outputPath);
        sc.close();
    }


}
