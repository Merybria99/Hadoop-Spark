import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;


class MapperBigData extends Mapper<Object, Text, Text, NullWritable> {


    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String[] values = value.toString().split("\\s+");
        for (String s : values)
            context.write(new Text(s),NullWritable.get());
    }
}
