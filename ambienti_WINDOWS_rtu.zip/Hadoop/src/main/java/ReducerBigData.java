import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

class ReducerBigData extends Reducer<Text,NullWritable,Text, IntWritable> {
    private IntWritable counter;

    @Override
    protected void setup(Reducer<Text, NullWritable, Text, IntWritable>.Context context) throws IOException, InterruptedException {
        counter = new IntWritable(0);
    }

    @Override
    protected void reduce(Text key, Iterable<NullWritable> values, Context context) throws IOException, InterruptedException {
        counter.set(counter.get()+1);
        context.write(key,counter);
    }
}
