import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class DriverBigData {


    public static void main(String[] args) throws Exception {

        //*
        System.setProperty("hadoop.home.dir", "cartella di hadoop DA INSERIRE");
        System.load("ddl di hadoop DA INSERIRE");
        //*/

        Configuration conf = new Configuration();
        conf.set("user",args[2]);

        Job job = Job.getInstance(conf);
        job.setJobName("Exercise");


        //job.setInputFormatClass(KeyValueTextInputFormat.class);

        job.setJarByClass(DriverBigData.class);
        job.setMapperClass(MapperBigData.class);
        //job.setCombinerClass(ReducerBigData.class);
        job.setReducerClass(ReducerBigData.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);


        /*
        job.setMapOutputKeyClass(NullWritable.class);
        job.setMapOutputValueClass(Text.class);
        */


        job.setNumReduceTasks(1);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

}
